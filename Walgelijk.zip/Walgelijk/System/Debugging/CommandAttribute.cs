﻿using System;

namespace Walgelijk
{
    /// <summary>
    /// Attribute that registers a command to the command processor registry
    /// </summary>
    public class CommandAttribute : Attribute
    {
        //public string Alias = null;
        //TODO alias
    }
}
