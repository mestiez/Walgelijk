﻿namespace Walgelijk
{
    public enum Button
    {
        Left,
        Middle,
        Right,
        Button1,
        Button2,
        Button3,
        Button4,
        Button5,
        Button6,
        Button7,
        Button8,
        Button9,
        LastButton
    }
}
